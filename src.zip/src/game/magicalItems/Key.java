package game.magicalItems;

import edu.monash.fit2099.engine.items.Item;

public class Key extends Item {
    /***
     * Constructor.
     */
    public Key() {
        super("Key", 'k', true);
    }
}
