package game;

import edu.monash.fit2099.engine.weapons.WeaponItem;

public class Wrench extends WeaponItem {
    /**
     * Constructor for wrench
     *
     */
    public Wrench() {
        super("Wrench", 'W', 50, "hits", 80);
        this.addCapability(Status.WRENCH);
    }

    public String verb() {
        return "hits";
    }


}
